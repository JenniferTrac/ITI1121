Student name: Jennifer Trac
Student number: 300053014
Course code: ITI1121
Lab section: A02

This archive contains the 7 files of lab 8, that is, this file (README.txt),
plus RandomExceptions.Java, Account.java, NotEnoughMoneyException.java, Map.java, Pair.java, Dictionary.java.
