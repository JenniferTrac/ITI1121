Student name: Jennifer Trac
Student number: 300053014
Course code: ITI1121
Lab section: A02

This archive contains the 6 files of lab 7, that is, this file (README.txt),
plus Controller.java, Timer.java, View.java, GraphicalView.java, TextView.java.
